
/*
** Watch_Face_Editor tool
** watchface js version v1.0.1
** Copyright © CashaCX75. All Rights Reserved
*/

try {

  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';

    //dynamic modify start


    let normal_background_bg_img = ''
    let normal_stand_circle_scale = ''
    let normal_date_img_date_day = ''
    let normal_date_img_date_week_img = ''
    let normal_battery_circle_scale = ''
    let normal_battery_text_text_img = ''
    let normal_temperature_current_text_img = ''
    let normal_weather_img = ''
    let normal_heart_rate_text_text_img = ''
    let normal_calorie_circle_scale = ''
    let normal_calorie_current_text_img = ''
    let normal_step_circle_scale = ''
    let normal_step_current_text_img = ''
    let normal_digital_clock_img_time = ''
    let normal_temperature_jumpable_img_click = ''
    let idle_date_img_date_day = ''
    let idle_date_img_date_week_img = ''
    let idle_digital_clock_img_time = ''


    //dynamic modify end

    //not required
    const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {

        //dynamic modify start


        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0 + 20,
          y: 0 - 20,
          w: 390,
          h: 450,
          src: '0001.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
        // center_x: 96,
        // center_y: 332,
        // start_angle: 0,
        // end_angle: 360,
        // radius: 48,
        // line_width: 19,
        // color: 0xFF09EBF7,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.STAND,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        let screenType = hmSetting.getScreenType();
        if (screenType != hmSetting.screen_type.AOD) {
          normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
        };

        const stand = hmSensor.createSensor(hmSensor.id.STAND);
        stand.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 160,
          month_startY: 397,
          month_sc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          month_tc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          month_en_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          month_align: hmUI.align.CENTER_H,
          month_zero: 1,
          month_follow: 0,
          month_space: 0,
          month_is_character: false,
          day_startX: 218,
          day_startY: 397,
          day_sc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          day_tc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          day_en_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          day_align: hmUI.align.CENTER_H,
          day_zero: 1,
          day_follow: 0,
          day_space: 0,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 270,
          y: 397,
          week_en: ["19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
          week_tc: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
          week_sc: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
        //   day_startX: 274,
        //   day_startY: 391,
        //   day_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
        //   day_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
        //   day_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
        //   day_zero: 0,
        //   day_space: 0,
        //   day_align: hmUI.align.RIGHT,
        //   day_is_character: false,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        // normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
        //   month_startX: 318,
        //   month_startY: 392,
        //   month_sc_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
        //   month_tc_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
        //   month_en_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
        //   month_is_character: true ,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
        // center_x: 329,
        // center_y: 58,
        // start_angle: 0,
        // end_angle: 360,
        // radius: 35,
        // line_width: 7,
        // color: 0xFF01C750,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.BATTERY,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });


        if (screenType != hmSetting.screen_type.AOD) {
          normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
        };

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 307,
          y: 48,
          font_array: ["0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        //   x: 34,
        //   y: 48,
        //   font_array: ["0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png"],
        //   padding: false,
        //   h_space: -2,
        //   unit_sc: '0079.png',
        //   unit_tc: '0079.png',
        //   unit_en: '0079.png',
        //   negative_image: '0080.png',
        //   align_h: hmUI.align.CENTER_H,
        //   type: hmUI.data_type.WEATHER_CURRENT,
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 66,
          y: 30,
          type: hmUI.data_type.WEATHER_CURRENT,
          font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
          align_h: hmUI.align.LEFT,
          h_space: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
          unit_sc: '62.png',//单位
          negative_image: '61.png', //负号图片
          invalid_image: '60.png',// 无数据时显示的图片
          padding: false,
          isCharacter: false
        });

        normal_weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 34,
          y: 30,
          image_array: ["123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png","151.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 262,
          y: 321,
          font_array: ["0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png", "0041.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
        // center_x: 96,
        // center_y: 331,
        // start_angle: 0,
        // end_angle: 360,
        // radius: 71,
        // line_width: 18,
        // color: 0xFF12ED12,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.CAL,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });


        if (screenType != hmSetting.screen_type.AOD) {
          normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
        };

        const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
        calorie.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 219,
          y: 251,
          font_array: ["0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
        // center_x: 97,
        // center_y: 331,
        // start_angle: 0,
        // end_angle: 360,
        // radius: 96,
        // line_width: 20,
        // color: 0xFFFF0006,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.STEP,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });


        if (screenType != hmSetting.screen_type.AOD) {
          normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
        };

        const step = hmSensor.createSensor(hmSensor.id.STEP);
        step.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 176,
          y: 181,
          font_array: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 92,
          hour_startY: 100,
          hour_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          hour_zero: 1,
          hour_space: 0,
          hour_unit_sc: '0042.png',
          hour_unit_tc: '0042.png',
          hour_unit_en: '0042.png',
          hour_align: hmUI.align.LEFT,

          minute_startX: 222,
          minute_startY: 100,
          minute_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          minute_zero: 1,
          minute_space: 0,
          minute_follow: 0,
          minute_align: hmUI.align.LEFT,

          second_startX: 340,
          second_startY: 100,
          second_array: ["0101.png", "0102.png", "0103.png", "0104.png", "0105.png", "0106.png", "0107.png", "0108.png", "0109.png", "0110.png"],
          second_zero: 1,
          second_space: 0,
          second_follow: 0,
          second_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 12,
          y: 7,
          w: 100,
          h: 100,
          src: '0081.png',
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 160,
          month_startY: 206,
          month_sc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          month_tc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          month_en_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          month_align: hmUI.align.CENTER_H,
          month_zero: 1,
          month_follow: 0,
          month_space: 0,
          month_is_character: false,
          day_startX: 218,
          day_startY: 206,
          day_sc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          day_tc_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          day_en_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
          day_align: hmUI.align.CENTER_H,
          day_zero: 1,
          day_follow: 0,
          day_space: 0,
          day_is_character: false,
          show_level: hmUI.show_level.ONAL_AOD,
        });

      idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 270,
          y: 206,
          week_en: ["19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
          week_tc: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
          week_sc: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
          show_level: hmUI.show_level.ONAL_AOD,
        });

        // idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
        //   day_startX: 274,
        //   day_startY: 200,
        //   day_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
        //   day_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
        //   day_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
        //   day_zero: 0,
        //   day_space: 0,
        //   day_align: hmUI.align.RIGHT,
        //   day_is_character: false,
        //   show_level: hmUI.show_level.ONAL_AOD,
        // });

        // idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
        //   month_startX: 318,
        //   month_startY: 200,
        //   month_sc_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
        //   month_tc_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
        //   month_en_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
        //   month_is_character: true ,
        //   show_level: hmUI.show_level.ONAL_AOD,
        // });

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 92 - 4,
          hour_startY: 100,
          hour_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          hour_zero: 1,
          hour_space: 0,
          hour_unit_sc: '0042.png',
          hour_unit_tc: '0042.png',
          hour_unit_en: '0042.png',
          hour_align: hmUI.align.LEFT,

          minute_startX: 222 - 4,
          minute_startY: 100,
          minute_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          minute_zero: 1,
          minute_space: 0,
          minute_follow: 0,
          minute_align: hmUI.align.LEFT,

          second_startX: 340 - 4,
          second_startY: 100,
          second_array: ["0101.png", "0102.png", "0103.png", "0104.png", "0105.png", "0106.png", "0107.png", "0108.png", "0109.png", "0110.png"],
          second_zero: 1,
          second_space: 0,
          second_follow: 0,
          second_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONAL_AOD,
        });

        function scale_call() {

          console.log('update scales STAND');

          let valueStand = stand.current;
          let targetStand = stand.target;
          let progressStand = valueStand / targetStand;
          if (progressStand > 1) progressStand = 1;
          let progress_cs_normal_stand = progressStand;

          if (screenType != hmSetting.screen_type.AOD) {

            // normal_stand_circle_scale
            // initial parameters
            let start_angle_normal_stand = -90;
            let end_angle_normal_stand = 270;
            let center_x_normal_stand = 96 + 20;
            let center_y_normal_stand = 332 - 20;
            let radius_normal_stand = 48;
            let line_width_cs_normal_stand = 19;
            let color_cs_normal_stand = 0xFF09EBF7;

            // calculated parameters
            let arcX_normal_stand = center_x_normal_stand - radius_normal_stand;
            let arcY_normal_stand = center_y_normal_stand - radius_normal_stand;
            let CircleWidth_normal_stand = 2 * radius_normal_stand;
            let angle_offset_normal_stand = end_angle_normal_stand - start_angle_normal_stand;
            angle_offset_normal_stand = angle_offset_normal_stand * progress_cs_normal_stand;
            let end_angle_normal_stand_draw = start_angle_normal_stand + angle_offset_normal_stand;

            normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {
              x: arcX_normal_stand,
              y: arcY_normal_stand,
              w: CircleWidth_normal_stand,
              h: CircleWidth_normal_stand,
              start_angle: start_angle_normal_stand,
              end_angle: end_angle_normal_stand_draw,
              color: color_cs_normal_stand,
              line_width: line_width_cs_normal_stand,
            });
          };

          console.log('update scales BATTERY');

          let valueBattery = battery.current;
          let targetBattery = 100;
          let progressBattery = valueBattery / targetBattery;
          if (progressBattery > 1) progressBattery = 1;
          let progress_cs_normal_battery = progressBattery;

          if (screenType != hmSetting.screen_type.AOD) {

            // normal_battery_circle_scale
            // initial parameters
            let start_angle_normal_battery = -90;
            let end_angle_normal_battery = 270;
            let center_x_normal_battery = 329;
            let center_y_normal_battery = 58;
            let radius_normal_battery = 35;
            let line_width_cs_normal_battery = 7;
            let color_cs_normal_battery = 0xFF01C750;

            // calculated parameters
            let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
            let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
            let CircleWidth_normal_battery = 2 * radius_normal_battery;
            let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
            angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
            let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;

            normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
              x: arcX_normal_battery,
              y: arcY_normal_battery,
              w: CircleWidth_normal_battery,
              h: CircleWidth_normal_battery,
              start_angle: start_angle_normal_battery,
              end_angle: end_angle_normal_battery_draw,
              color: color_cs_normal_battery,
              line_width: line_width_cs_normal_battery,
            });
          };

          console.log('update scales CALORIE');

          let valueCalories = calorie.current;
          let targetCalories = calorie.target;
          let progressCalories = valueCalories / targetCalories;
          if (progressCalories > 1) progressCalories = 1;
          let progress_cs_normal_calorie = progressCalories;

          if (screenType != hmSetting.screen_type.AOD) {

            // normal_calorie_circle_scale
            // initial parameters
            let start_angle_normal_calorie = -90;
            let end_angle_normal_calorie = 270;
            let center_x_normal_calorie = 96 + 20;
            let center_y_normal_calorie = 331 - 20;
            let radius_normal_calorie = 71;
            let line_width_cs_normal_calorie = 18;
            let color_cs_normal_calorie = 0xFF12ED12;

            // calculated parameters
            let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
            let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
            let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
            let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
            angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
            let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;

            normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
              x: arcX_normal_calorie,
              y: arcY_normal_calorie,
              w: CircleWidth_normal_calorie,
              h: CircleWidth_normal_calorie,
              start_angle: start_angle_normal_calorie,
              end_angle: end_angle_normal_calorie_draw,
              color: color_cs_normal_calorie,
              line_width: line_width_cs_normal_calorie,
            });
          };

          console.log('update scales STEP');

          let valueStep = step.current;
          let targetStep = step.target;
          let progressStep = valueStep / targetStep;
          if (progressStep > 1) progressStep = 1;
          let progress_cs_normal_step = progressStep;

          if (screenType != hmSetting.screen_type.AOD) {

            // normal_step_circle_scale
            // initial parameters
            let start_angle_normal_step = -90;
            let end_angle_normal_step = 270;
            let center_x_normal_step = 97 + 20;
            let center_y_normal_step = 331 - 20;
            let radius_normal_step = 96;
            let line_width_cs_normal_step = 20;
            let color_cs_normal_step = 0xFFFF0006;

            // calculated parameters
            let arcX_normal_step = center_x_normal_step - radius_normal_step;
            let arcY_normal_step = center_y_normal_step - radius_normal_step;
            let CircleWidth_normal_step = 2 * radius_normal_step;
            let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
            angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
            let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;

            normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
              x: arcX_normal_step,
              y: arcY_normal_step,
              w: CircleWidth_normal_step,
              h: CircleWidth_normal_step,
              start_angle: start_angle_normal_step,
              end_angle: end_angle_normal_step_draw,
              color: color_cs_normal_step,
              line_width: line_width_cs_normal_step,
            });
          };

        };

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            scale_call();
          }),
        });

        //dynamic modify end
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()

      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });

  })()
} catch (e) {
  console.log(e)
}



