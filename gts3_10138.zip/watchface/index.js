﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-0000.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 200,
              minute_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec-0000.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 200,
              second_posY: 200,
              second_cover_path: 'sec-open.png',
              second_cover_x: 0,
              second_cover_y: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 139,
              hour_startY: 187,
              hour_array: ["on-0000.png","on-0001.png","on-0002.png","on-0003.png","on-0004.png","on-0005.png","on-0006.png","on-0007.png","on-0008.png","on-0009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 273,
              minute_startY: 207,
              minute_array: ["mn-0000.png","mn-0001.png","mn-0002.png","mn-0003.png","mn-0004.png","mn-0005.png","mn-0006.png","mn-0007.png","mn-0008.png","mn-0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 0,
              w: 390,
              h: 450,
              src: 'aodsecalt.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-0000.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 200,
              minute_posY: 200,
              minute_cover_path: 'aodmin.png',
              minute_cover_x: 0,
              minute_cover_y: 25,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 139,
              hour_startY: 187,
              hour_array: ["on-0000.png","on-0001.png","on-0002.png","on-0003.png","on-0004.png","on-0005.png","on-0006.png","on-0007.png","on-0008.png","on-0009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 273,
              minute_startY: 207,
              minute_array: ["mn-0000.png","mn-0001.png","mn-0002.png","mn-0003.png","mn-0004.png","mn-0005.png","mn-0006.png","mn-0007.png","mn-0008.png","mn-0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  