try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: e
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__),
            p = Logger.getLogger("watchface6");
        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_eskmz",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: 61,
                    display_on_restart: !1,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 125,
                    month_startY: 74,
                    month_sc_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    month_tc_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    month_en_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    month_unit_sc: "15.png",
                    month_unit_tc: "15.png",
                    month_unit_en: "15.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_sc_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    day_tc_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    day_en_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    day_zero: 1,
                    day_follow: 1,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 135,
                    y: 119,
                    week_en: ["16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png"],
                    week_tc: ["23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    week_sc: ["30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 21,
                    hour_startY: 170,
                    hour_array: ["37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png"],
                    hour_space: 0,
                    hour_unit_sc: "47.png",
                    hour_unit_tc: "47.png",
                    hour_unit_en: "47.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 207,
                    minute_startY: 170,
                    minute_array: ["37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 158,
                    y: 287,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "48.png",
                    unit_tc: "48.png",
                    unit_en: "48.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 120,
                    y: 287,
                    src: "49.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 161,
                    y: 332,
                    type: hmUI.data_type.STEP,
                    font_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "50.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 111,
                    y: 332,
                    src: "51.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 155,
                    y: 330,
                    w: 130,
                    h: 35,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "52.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 28,
                    hour_startY: 170,
                    hour_array: ["37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png"],
                    hour_space: 0,
                    hour_unit_sc: "47.png",
                    hour_unit_tc: "47.png",
                    hour_unit_en: "47.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 218,
                    minute_startY: 173,
                    minute_array: ["37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}