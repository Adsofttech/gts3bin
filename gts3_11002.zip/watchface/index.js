﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let editGroup_1  = ''
        let editableZone_2_city_name_text = null;
        let editGroup_2  = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 390,
              // h: 450,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: '1_preview.png', path: 'bg.png' },
                { id: 2, preview: '2_preview.png', path: 'bg1.png' },
                { id: 3, preview: '3_preview.png', path: 'bg2.png' },
                { id: 4, preview: '4_preview.png', path: 'bg3.png' },
                { id: 5, preview: '5_preview.png', path: 'bg4.png' },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_bg: 'option_1.png',
              tips_x: 144,
              tips_y: 8,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 249,
              day_startY: 47,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 25,
              y: 39,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 92,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 145,
              minute_startY: 92,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 295,
              second_startY: 121,
              second_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 98,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 19,
              y: 194,
              w: 360,
              h: 160,
              select_image: 'option_2.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
              ],
              count: 0,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'option_1.png',
              tips_x: 215,
              tips_y: 4,
              tips_width: 132,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 31,
                  y: 202,
                  src: 'staps_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 27,
                  y: 322,
                  image_array: ["img_steps_1.png","img_steps_2.png","img_steps_3.png","img_steps_4.png","img_steps_5.png","img_steps_6.png","img_steps_7.png","img_steps_8.png","img_steps_9.png","img_steps_10.png","img_steps_11.png","img_steps_12.png"],
                  image_length: 12,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 71,
                  y: 240,
                  font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
                  padding: false,
                  h_space: 3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 27,
                  y: 203,
                  src: 'calories_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 47,
                  y: 249,
                  font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
                  padding: false,
                  h_space: 3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
                  x: [36,77,117,157,197,237,277,317],
                  y: [331,329,327,326,323,312,285,213],
                  image_array: ["img_kcal_1.png","img_kcal_2.png","img_kcal_3.png","img_kcal_4.png","img_kcal_5.png","img_kcal_6.png","img_kcal_7.png","img_kcal_8.png"],
                  image_length: 8,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 31,
                  y: 202,
                  src: 'puls_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 120,
                  y: 251,
                  font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
                  padding: false,
                  h_space: 3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 31,
                  y: 202,
                  src: 'pai_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 38,
                  y: 255,
                  font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
                  padding: false,
                  h_space: 3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 220,
                  src: 'pai_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 241,
                  y: 250,
                  image_array: ["img_pai_1.png","img_pai_2.png","img_pai_3.png","img_pai_4.png","img_pai_5.png","img_pai_6.png","img_pai_7.png","img_pai_8.png","img_pai_10.png","img_pai_11.png","img_pai_12.png","img_pai_13.png"],
                  image_length: 12,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 44,
                  y: 248,
                  font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'km.png',
                  unit_tc: 'km.png',
                  unit_en: 'km.png',
                  imperial_unit_sc: 'ml.png',
                  imperial_unit_tc: 'ml.png',
                  imperial_unit_en: 'ml.png',
                  dot_image: 'pointer_7.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 31,
                  y: 202,
                  src: 'distance_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 31,
                  y: 202,
                  src: 'stand_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 103,
                  y: 230,
                  font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
                  padding: false,
                  h_space: 4,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 22,
                  y: 200,
                  src: 'stress_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: 'pointer_8.png',
                  center_x: 231,
                  center_y: 338,
                  x: 16,
                  y: 85,
                  start_angle: -93,
                  end_angle: 93,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 42,
                  y: 255,
                  font_array: ["font_sec_0.png","font_sec_1.png","font_sec_2.png","font_sec_3.png","font_sec_4.png","font_sec_5.png","font_sec_6.png","font_sec_7.png","font_sec_8.png","font_sec_9.png"],
                  padding: false,
                  h_space: 3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 163,
                  y: 201,
                  image_array: ["img_stress_1.png","img_stress_2.png","img_stress_3.png","img_stress_4.png","img_stress_5.png","img_stress_6.png","img_stress_7.png","img_stress_8.png","img_stress_9.png","img_stress_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 19,
              y: 362,
              w: 351,
              h: 74,
              select_image: 'option_3.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
              ],
              count: 0,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'option_1.png',
              tips_x: 207,
              tips_y: 4,
              tips_width: 132,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 28,
                  y: 362,
                  src: 'weather_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 242,
                  y: 367,
                  image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_2_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 146,
                  y: 363,
                  w: 150,
                  h: 30,
                  text_size: 16,
                  char_space: 1,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 72,
                  y: 393,
                  font_array: ["font_sec_0.png","font_sec_1.png","font_sec_2.png","font_sec_3.png","font_sec_4.png","font_sec_5.png","font_sec_6.png","font_sec_7.png","font_sec_8.png","font_sec_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'pointer_4.png',
                  unit_tc: 'pointer_4.png',
                  unit_en: 'pointer_4.png',
                  negative_image: 'pointer_3.png',
                  invalid_image: 'dot.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            function scale_call() {

              console.log('Edit element Wearther city name');

              if(editableZone_2_city_name_text){
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              editableZone_2_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}