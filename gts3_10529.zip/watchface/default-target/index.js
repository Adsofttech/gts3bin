try {
    (() => {
    
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        
	const Numbers_big_array = [
             'Numbers_big_00.png',
             'Numbers_big_01.png',
             'Numbers_big_02.png',
             'Numbers_big_03.png',
             'Numbers_big_04.png',
             'Numbers_big_05.png',
             'Numbers_big_06.png',
             'Numbers_big_07.png',
             'Numbers_big_08.png',
             'Numbers_big_09.png'];
             
        const Numbers_L_array = [
             'Numbers_L_00.png',
             'Numbers_L_01.png',
             'Numbers_L_02.png',
             'Numbers_L_03.png',
             'Numbers_L_04.png',
             'Numbers_L_05.png',
             'Numbers_L_06.png',
             'Numbers_L_07.png',
             'Numbers_L_08.png',
             'Numbers_L_09.png'];
        
        const Numbers_dot_big_array = ['0004.png','0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png'];
        
        const font_bigger_array = ['font_bigger_0.png', 'font_bigger_1.png', 'font_bigger_2.png', 'font_bigger_3.png', 'font_bigger_4.png', 'font_bigger_5.png', 'font_bigger_6.png', 'font_bigger_7.png', 'font_bigger_8.png', 'font_bigger_9.png'];
        
        const font_digital_array = ['digital_0.png', 'digital_1.png', 'digital_2.png', 'digital_3.png', 'digital_4.png', 'digital_5.png', 'digital_6.png', 'digital_7.png', 'digital_8.png', 'digital_9.png'];        
        const font_small_array = ['font_small_0.png','font_small_1.png','font_small_2.png','font_small_3.png','font_small_4.png','font_small_5.png','font_small_6.png','font_small_7.png','font_small_8.png','font_small_9.png'];
        
        const font_hour_red_array = ['font_hour_0_red.png','font_hour_1_red.png','font_hour_2_red.png','font_hour_3_red.png','font_hour_4_red.png','font_hour_5_red.png','font_hour_6_red.png','font_hour_7_red.png','font_hour_8_red.png','font_hour_9_red.png'];
        
        const font_hour_gray_array = ['font_hour_0_gray.png','font_hour_1_gray.png','font_hour_2_gray.png','font_hour_3_gray.png','font_hour_4_gray.png','font_hour_5_gray.png','font_hour_6_gray.png','font_hour_7_gray.png','font_hour_8_gray.png','font_hour_9_gray.png'];
        
        const font_hour_blue_array = ['font_hour_0_blue.png','font_hour_1_blue.png','font_hour_2_blue.png','font_hour_3_blue.png','font_hour_4_blue.png','font_hour_5_blue.png','font_hour_6_blue.png','font_hour_7_blue.png','font_hour_8_blue.png','font_hour_9_blue.png'];
        
        const font_hour_green_array = ['font_hour_0_green.png','font_hour_1_green.png','font_hour_2_green.png','font_hour_3_green.png','font_hour_4_green.png','font_hour_5_green.png','font_hour_6_green.png','font_hour_7_green.png','font_hour_8_green.png','font_hour_9_green.png'];

	const font_hour_cyan_array = ['font_hour_0_cyan.png','font_hour_1_cyan.png','font_hour_2_cyan.png','font_hour_3_cyan.png','font_hour_4_cyan.png','font_hour_5_cyan.png','font_hour_6_cyan.png','font_hour_7_cyan.png','font_hour_8_cyan.png','font_hour_9_cyan.png'];
             
        const Numbers_dot_array = ['0066.png','0067.png','0068.png','0069.png','0070.png','0071.png','0072.png','0073.png','0074.png','0075.png'];
        
        const Battery_img_array = ['0078.png','0079.png','0080.png','0081.png','0082.png','0083.png','0084.png','0085.png','0086.png','0087.png','0088.png','0089.png','0090.png','0091.png','0092.png'];
             
        const weekbar_array = [
             'week_01.png','week_02.png','week_03.png','week_04.png',
             'week_05.png','week_06.png','week_07.png'];
        const week_vert_array = [
             'week_vert_01.png','week_vert_02.png','week_vert_03.png','week_vert_04.png',
             'week_vert_05.png','week_vert_06.png','week_vert_07.png'];
        const wday_array = [
             'day_1.png','day_2.png','day_3.png','day_4.png',
             'day_5.png','day_6.png','day_7.png'];
        const weekcenter_array = [
             'weekc_01.png','weekc_02.png','weekc_03.png','weekc_04.png',
             'weekc_05.png','weekc_06.png','weekc_07.png'];
             
        const step_array = ['step_0.png','step_1.png','step_2.png','step_3.png','step_4.png','step_5.png','step_6.png','step_7.png','step_8.png','step_9.png'];
        
        const power_array = ['power_18.png','power_19.png','power_20.png','power_21.png','power_22.png','power_23.png','power_24.png','power_25.png','power_27.png','power_27.png'];
        
        let list_timer = ['gray', 'red', 'blue', 'green', 'cyan'];     
        let image_time_minute = [];
        let image_time_hour = [];
        let image_time_aod = '';
        let config_time_params_hour = {};
        let config_time_params_minute = {};
        let config_time_params_aod = {};
        let normal_digital_clock_minute_separator_img = '';
        let image_bt = '';
        let image_bt_aod = '';
        let btn_aod = '';
        let btn_battery = '';
        let image_week = '';
        let image_battery_icon = '';
        let image_battery = '';
        let image_battery_icon_aod = '';
        let image_battery_aod = '';
        let curAODmode = 0; // 0 - AOD Minimal  // 1 - AOD Disabled
        
        let btn_change_hour = '';
        let btn_change_minute = '';
        let toggle_hour = 0;
        let toggle_minute = 0;
        let type_hour = font_hour_gray_array;
        let type_minute = font_hour_gray_array;
        
        hmFS.SysProSetInt('parkur_toggle_hour', toggle_hour);
        hmFS.SysProSetInt('parkur_toggle_minute', toggle_minute);
        

        let AODmodes = ["Minimal", "Disabled"];
        
        let AODmodeCaption = '';
        
        function toggleAODmode() {
            curAODmode = (curAODmode + 1) % AODmodes.length;
            hmFS.SysProSetInt('parkur_aod', curAODmode);

            switch (curAODmode) {
                case 0:
                    AODmodeCaption = "Enabled";
                    break;
                case 1:
                    AODmodeCaption = "Disabled";
                    break;
                default:
                    AODmodeCaption = "";
                    break;
            }

            hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
        }
        
        function ShowBatteryInfo() {
          const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
          hmUI.showToast({ text: 'Battery level\n' + battery.current + '%' });
        }
        
        function makeAOD() {
            let mode = hmFS.SysProGetInt('parkur_aod');
            
	    config_time_params_aod = {
                    hour_zero: 1,
                    hour_startX: 40,
                    hour_startY: 97,
                    hour_array: get_array_hour(0),
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 200,
                    minute_startY: 177,
                    minute_array: get_array_minute(0),
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                };
            image_bt_aod = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 312,
                    y: 5,
                    src: '114.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                
            // BATTERY AOD 
                image_battery_icon_aod = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 125,
                    y: 418,
                    image_array: Battery_img_array,
                    image_length: 15,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                image_battery_icon_aod.setProperty(hmUI.prop.VISIBLE, false);
                image_battery_aod = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 215,
                    y: 420,
                    type: hmUI.data_type.BATTERY,
                    font_array: font_small_array,
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: false,
                    unit_en: 'pointer_2.png',
                    isCharacter: false
                });
                image_battery_aod.setProperty(hmUI.prop.VISIBLE, false);
	    let image_time_aod = hmUI.createWidget(hmUI.widget.IMG_TIME, config_time_params_aod);			
	    if (mode == 0) { // ENABLE
                image_time_aod.setProperty(hmUI.prop.VISIBLE, true);
                //image_battery_icon_aod.setProperty(hmUI.prop.VISIBLE, true);   
                //image_battery_aod.setProperty(hmUI.prop.VISIBLE, true);   
	    }
	    if (mode == 1) { // DISABLE
                image_time_aod.setProperty(hmUI.prop.VISIBLE, false);
                //image_battery_icon_aod.setProperty(hmUI.prop.VISIBLE, false);                
                //image_battery_aod.setProperty(hmUI.prop.VISIBLE, false);                
	    }
        }                
        
        function change_hour() {
           toggle_hour = hmFS.SysProGetInt('parkur_toggle_hour');
           let cc = 0;
           for (let v of list_timer) {
              image_time_hour[cc].setProperty(hmUI.prop.VISIBLE, false);
              cc = cc + 1;
           }
           toggle_hour = toggle_hour + 1;
           if (toggle_hour > 4) { 
           	toggle_hour = 0; 
           }
           hmFS.SysProSetInt('parkur_toggle_hour', toggle_hour);
           let hint = 'Hour: Change Color  \n';
           switch (toggle_hour) {
                case 0:
                  type_hour = font_hour_gray_array;
                  hint = hint + 'Gray';
                  break;
                case 1:
                  type_hour = font_hour_red_array;
                  hint = hint + 'Red';
                  break;
                case 2:
                  type_hour = font_hour_blue_array;
                  hint = hint + 'Blue';
                  break;
                case 3:
                  type_hour = font_hour_green_array;
                  hint = hint + 'Green';
                  break;
                case 4:
                  type_hour = font_hour_cyan_array;
                  hint = hint + 'Cyan';
                  break;
                case 5:
                  type_hour = font_bigger_array;
                  hint = hint + 'Digital';
           } 
           //hmUI.showToast({ text: hint });
           UpdateTime();
        }
        
        function change_minute() {
           toggle_minute = hmFS.SysProGetInt('parkur_toggle_minute');
           let cc = 0;
           for (let v of list_timer) {
              image_time_minute[cc].setProperty(hmUI.prop.VISIBLE, false);
              cc = cc + 1;
           }
           toggle_minute = toggle_minute + 1;
           if (toggle_minute > 4) { 
           	toggle_minute = 0; 
           }
           hmFS.SysProSetInt('parkur_toggle_minute', toggle_minute);
           let hint = 'Minute: Change Color \n';
           switch (toggle_minute) {
                case 0:
                  type_minute = font_hour_gray_array;
                  hint = hint + 'Gray';
                  break;
                case 1:
                  type_minute = font_hour_red_array;
                  hint = hint + 'Red';
                  break;
                case 2:
                  type_minute = font_hour_blue_array;
                  hint = hint + 'Blue';
                  break;
                case 3:
                  type_minute = font_hour_green_array;
                  hint = hint + 'Green';
                  break;
                case 4:
                  type_minute = font_hour_cyan_array;
                  hint = hint + 'Cyan';
                  break;
                case 5:
                  type_minute = font_bigger_array;
                  hint = hint + 'Digital';
                  break;
           } 
           //hmUI.showToast({ text: hint });
           UpdateTime();
        }
        
        function get_array_hour(toggle) {
            let toggle_hour = hmFS.SysProGetInt('parkur_toggle_hour');
            let type_hour = '';
            switch (toggle) {
                case 0:
                  type_hour = font_hour_gray_array;
                  break;
                case 1:
                  type_hour = font_hour_red_array;
                  break;
                case 2:
                  type_hour = font_hour_blue_array;
                  break;
                case 3:
                  type_hour = font_hour_green_array;
                  break;
                case 4:
                  type_hour = font_hour_cyan_array;
                  break;
                case 5:
                  type_hour = font_bigger_array;
                  break;
           }
           return type_hour;
        }
        
        function get_array_minute(toggle) {
            let toggle_minute = hmFS.SysProGetInt('parkur_toggle_minute');
            let type_minute = '';
            switch (toggle) {
                case 0:
                  type_minute = font_hour_gray_array;
                  break;
                case 1:
                  type_minute = font_hour_red_array;
                  break;
                case 2:
                  type_minute = font_hour_blue_array;
                  break;
                case 3:
                  type_minute = font_hour_green_array;
                  break;
                case 4:
                  type_minute = font_hour_cyan_array;
                  break;
                case 5:
                  type_minute = font_bigger_array;
                  break;
           }
           return type_minute;
        }
        
        function UpdateTime(){
          config_time_params_hour['hour_array'] = get_array_hour(toggle_hour);
          config_time_params_minute['minute_array'] = get_array_hour(toggle_minute);
          image_time_hour[toggle_hour].setProperty(hmUI.prop.MORE, config_time_params_hour);
          image_time_hour[toggle_hour].setProperty(hmUI.prop.VISIBLE, true);
          image_time_minute[toggle_minute].setProperty(hmUI.prop.MORE, config_time_params_minute);
          image_time_minute[toggle_minute].setProperty(hmUI.prop.VISIBLE, true);
          image_time_hour.redraw();
          image_time_minute.redraw();
        }
        
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
            init_view() {
            	config_time_params_hour = {
                    hour_zero: 1,
                    hour_startX: 40,
                    hour_startY: 97,
                    hour_array: type_hour,
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                    };
               config_time_params_minute = {     
                    minute_zero: 1,
                    minute_startX: 200,
                    minute_startY: 177,
                    minute_array: type_minute,
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                    
                };
		
		hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                
                let conth = 0;
                for (const element of list_timer) {
                   config_time_params_hour['hour_array'] = get_array_hour(conth);
                   image_time_hour[conth] = hmUI.createWidget(hmUI.widget.IMG_TIME, config_time_params_hour);
                   image_time_hour[conth].setProperty(hmUI.prop.VISIBLE, false);
                   conth = conth + 1;
                  
                }
                image_time_hour[0].setProperty(hmUI.prop.VISIBLE, true);
                
                let contm = 0;
                for (const element of list_timer) {
                   config_time_params_minute['minute_array'] = get_array_minute(contm);
                   image_time_minute[contm] = hmUI.createWidget(hmUI.widget.IMG_TIME, config_time_params_minute);
                   image_time_minute[contm].setProperty(hmUI.prop.VISIBLE, false);
                   contm = contm + 1;
                }
                image_time_minute[0].setProperty(hmUI.prop.VISIBLE, true);

		normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              		x: 241,
              		y: 193,
              		src: '1110002.png',
              		show_level: hmUI.show_level.ONLY_NORMAL,
            	});
            	normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            	

		image_bt = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 312,
                    y: 5,
                    src: '114.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                image_bt.setProperty(hmUI.prop.VISIBLE, true);
                
                image_week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 236,
                    y: 370,
                    week_en: wday_array,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                image_week.setProperty(hmUI.prop.VISIBLE, false);
                
                // BATTERY NORMAL 
                image_battery_icon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 125,
                    y: 418,
                    image_array: Battery_img_array,
                    image_length: 15,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                image_battery_icon.setProperty(hmUI.prop.VISIBLE, false);
                image_battery = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 215,
                    y: 420,
                    type: hmUI.data_type.BATTERY,
                    font_array: font_small_array,
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    unit_en: 'pointer_2.png',
                    isCharacter: false
                });
                image_battery.setProperty(hmUI.prop.VISIBLE, false);
                
                // vibration when connecting or disconnecting

		function checkConnection() {
		  hmBle.removeListener;
		  hmBle.addListener(function (status) {
		    if(!status) {
		      hmUI.showToast({text: "CONNECTION LOST"});
		      console.log('Disconnected');
		      vibro(9);
		    }
		    if(status) {
		      hmUI.showToast({text: "CONNECTION RESTORED"});
		      console.log('Connected');
		      vibro(9);
		    }
		  });
		}

		// end vibration when connecting or disconnecting
		
		// vibrate function

		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let timer_StopVibrate = null;


		function vibro(scene = 25) {
		  let stopDelay = 50;
		  stopVibro();
		  vibrate.stop();
		  vibrate.scene = scene;
		  if(scene < 23 || scene > 25) stopDelay = 1300;
		  vibrate.start();
		  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
		}

		function stopVibro(){
		  vibrate.stop();
		  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
		}

		// end vibrate function
		
		//START AOD Button
		btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 310,
		  y: 0,
                  text: '',
                  w: 60,
                  h: 60,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    toggleAODmode();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_aod.setProperty(hmUI.prop.VISIBLE, true);
		//END AOD Button
		
		//START Show Battery Button
		btn_battery = hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 160,
                  y: 390,
                  text: '',
                  w: 60,
                  h: 60,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    ShowBatteryInfo();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_battery.setProperty(hmUI.prop.VISIBLE, true);
		
		btn_change_hour = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 35,
		  y: 90,
                  text: '',
                  w: 153,
                  h: 127,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    change_hour();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_change_hour.setProperty(hmUI.prop.VISIBLE, true);
		
		btn_change_minute = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 195,
		  y: 170,
                  text: '',
                  w: 153,
                  h: 127,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    change_minute();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_change_minute.setProperty(hmUI.prop.VISIBLE, true);
		
		
		const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                  resume_call: (function () {
                    checkConnection();
                    stopVibro();
                  }),
                  pause_call: (function () {
                    stopVibro();
                  }),
                });                
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
		const currentScreenType = hmSetting.getScreenType();
                switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;
                  default:
                      break;
              	}            
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
