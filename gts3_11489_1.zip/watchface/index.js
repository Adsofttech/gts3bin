﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let editGroup_1  = ''
        let editableZone_2_battery_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_battery_circle_scale = null;
        let editGroup_3  = ''
        let editableZone_4_battery_circle_scale = null;
        let editGroup_4  = ''
        let editableZone_5_battery_circle_scale = null;
        let editGroup_5  = ''
        let normal_system_disconnect_img = ''
        let normal_step_target_TextCircle = new Array(5);
        let normal_step_target_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_target_TextCircle_img_width = 11;
        let normal_step_target_TextCircle_img_height = 14;
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });
            console.log('Watch_Face.Editable_Elements before AOD');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 40,
              y: 318,
              w: 100,
              h: 100,
              select_image: '179.png',
              un_select_image: '179.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(1)_HUMIDITY.png' },
              ],
              count: 2,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '178.png',
              tips_x: 0,
              tips_y: 2,
              tips_width: 99,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 40,
                  y: 320,
                  src: '135.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 83,
                  y: 402,
                  font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
                  padding: false,
                  h_space: 0,
                  negative_image: '215.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 53,
                  y: 402,
                  font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
                  padding: false,
                  h_space: 0,
                  negative_image: '215.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 55,
                  y: 352,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  negative_image: '203.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 36,
                  y: 319,
                  src: '180.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 57,
                  y: 352,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            let screenType = hmSetting.getScreenType();            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 144,
              y: 318,
              w: 100,
              h: 100,
              select_image: '179.png',
              un_select_image: '179.png',
              default_type: hmUI.edit_type.UVI,
              optional_types: [
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(2)_WIND.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.MOON, preview: 'ez(2)_MOON.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(2)_HEART.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(2)_ALTIMETER.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY.png' },
              ],
              count: 9,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '178.png',
              tips_x: 0,
              tips_y: 0,
              tips_width: 100,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 151,
                  y: 324,
                  src: '269.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 196,
                  // center_y: 370,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 45,
                  // line_width: 9,
                  // line_cap: Rounded,
                  // color: 0xFF21DE6C,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 196,
                  center_y: 370,
                  start_angle: 0,
                  end_angle: 360,
                  radius: 41,
                  line_width: 9,
                  corner_flag: 0,
                  color: 0xFF21DE6C,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                battery.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 162,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 146,
                  y: 321,
                  src: '182.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 171,
                  y: 359,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 163,
                  y: 358,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: '227.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 144,
                  y: 320,
                  src: '136.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 194,
                  center_y: 367,
                  x: -34,
                  y: 0,
                  start_angle: 121,
                  end_angle: 397,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 183,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 140,
                  y: 320,
                  src: '180.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 194,
                  center_y: 369,
                  x: -34,
                  y: 0,
                  start_angle: 121,
                  end_angle: 397,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 160,
                  y: 352,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 144,
                  y: 320,
                  src: '183.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '238.png',
                  center_x: 193,
                  center_y: 369,
                  x: 12,
                  y: 33,
                  start_angle: -90,
                  end_angle: 90,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 172,
                  y: 384,
                  font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 150,
                  y: 323,
                  src: '176.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 154,
                  y: 377,
                  font_array: ["216.png","217.png","218.png","219.png","220.png","221.png","222.png","223.png","224.png","225.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: '226.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 151,
                  y: 323,
                  image_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 172,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 150,
                  y: 323,
                  image_array: ["146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 246,
              y: 319,
              w: 100,
              h: 100,
              select_image: '179.png',
              un_select_image: '179.png',
              default_type: hmUI.edit_type.WIND,
              optional_types: [
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(3)_DISTANCE.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(3)_UVI.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER.png' },
                { type: hmUI.edit_type.MOON, preview: 'ez(3)_MOON.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(3)_SUN.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(3)_HUMIDITY.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(3)_BATTERY.png' },
              ],
              count: 9,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '178.png',
              tips_x: 1,
              tips_y: -2,
              tips_width: 100,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 253,
                  y: 324,
                  src: '269.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 299,
                  // center_y: 370,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 45,
                  // line_width: 9,
                  // line_cap: Rounded,
                  // color: 0xFF21DE6C,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 299,
                  center_y: 370,
                  start_angle: 0,
                  end_angle: 360,
                  radius: 41,
                  line_width: 9,
                  corner_flag: 0,
                  color: 0xFF21DE6C,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 265,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 250,
                  y: 321,
                  src: '182.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 275,
                  y: 359,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 264,
                  y: 358,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: '227.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 248,
                  y: 321,
                  src: '136.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 298,
                  center_y: 369,
                  x: 47,
                  y: 0,
                  start_angle: -34,
                  end_angle: 233,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 275,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 245,
                  y: 320,
                  src: '180.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 298,
                  center_y: 370,
                  x: -35,
                  y: 0,
                  start_angle: 121,
                  end_angle: 398,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 265,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 248,
                  y: 320,
                  src: '183.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '238.png',
                  center_x: 298,
                  center_y: 367,
                  x: 12,
                  y: 33,
                  start_angle: -90,
                  end_angle: 90,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 276,
                  y: 384,
                  font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 253,
                  y: 323,
                  src: '184.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 253,
                  y: 323,
                  image_array: ["185.png","186.png","187.png","188.png","189.png","190.png","191.png","192.png"],
                  image_length: 8,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 252,
                  y: 323,
                  image_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 273,
                  y: 353,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 253,
                  y: 324,
                  image_array: ["146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 40,
              y: 34,
              w: 100,
              h: 100,
              select_image: '179.png',
              un_select_image: '179.png',
              default_type: hmUI.edit_type.MOON,
              optional_types: [
                { type: hmUI.edit_type.MOON, preview: 'ez(4)_MOON.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(4)_SUN.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(4)_ALTIMETER.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(4)_WIND.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(4)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(4)_UVI.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(4)_DISTANCE.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(4)_HEART.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(4)_BATTERY.png' },
              ],
              count: 9,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '178.png',
              tips_x: 0,
              tips_y: 1,
              tips_width: 100,
              tips_margin: 0,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 45,
                  y: 40,
                  src: '269.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_4_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 90,
                  // center_y: 85,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 45,
                  // line_width: 9,
                  // line_cap: Rounded,
                  // color: 0xFF21DE6C,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_4_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 90,
                  center_y: 85,
                  start_angle: 0,
                  end_angle: 360,
                  radius: 41,
                  line_width: 9,
                  corner_flag: 0,
                  color: 0xFF21DE6C,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 56,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 40,
                  y: 38,
                  src: '182.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 65,
                  y: 78,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 58,
                  y: 75,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: '227.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 38,
                  y: 38,
                  src: '136.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 88,
                  center_y: 86,
                  x: -35,
                  y: 0,
                  start_angle: 125,
                  end_angle: 398,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 65,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 35,
                  y: 36,
                  src: '180.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 88,
                  center_y: 86,
                  x: -35,
                  y: 0,
                  start_angle: 125,
                  end_angle: 398,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 55,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 38,
                  y: 37,
                  src: '183.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '238.png',
                  center_x: 88,
                  center_y: 84,
                  x: 12,
                  y: 33,
                  start_angle: -90,
                  end_angle: 90,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 66,
                  y: 102,
                  font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 45,
                  y: 40,
                  src: '184.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 45,
                  y: 40,
                  image_array: ["185.png","186.png","187.png","188.png","189.png","190.png","191.png","192.png"],
                  image_length: 8,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 45,
                  y: 40,
                  image_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 66,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 45,
                  y: 40,
                  image_array: ["146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_5 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10025,
              x: 142,
              y: 37,
              w: 100,
              h: 100,
              select_image: '179.png',
              un_select_image: '179.png',
              default_type: hmUI.edit_type.SUN,
              optional_types: [
                { type: hmUI.edit_type.SUN, preview: 'ez(5)_SUN.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(5)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(5)_DISTANCE.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(5)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(5)_HUMIDITY.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(5)_WIND.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(5)_ALTIMETER.png' },
                { type: hmUI.edit_type.MOON, preview: 'ez(5)_MOON.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(5)_BATTERY.png' },
              ],
              count: 9,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '178.png',
              tips_x: 0,
              tips_y: -2,
              tips_width: 100,
              tips_margin: 0,
            });

            const editType_5 = editGroup_5.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_5) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 149,
                  y: 40,
                  src: '269.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_5_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 194,
                  // center_y: 85,
                  // start_angle: 0,
                  // end_angle: 360,
                  // radius: 45,
                  // line_width: 9,
                  // line_cap: Rounded,
                  // color: 0xFF21DE6C,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 194,
                  center_y: 85,
                  start_angle: 0,
                  end_angle: 360,
                  radius: 41,
                  line_width: 9,
                  corner_flag: 0,
                  color: 0xFF21DE6C,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 160,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 145,
                  y: 39,
                  src: '182.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 171,
                  y: 78,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 161,
                  y: 75,
                  font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: '227.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 143,
                  y: 38,
                  src: '136.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 193,
                  center_y: 87,
                  x: -35,
                  y: 0,
                  start_angle: 125,
                  end_angle: 398,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 170,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 139,
                  y: 38,
                  src: '180.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '204.png',
                  center_x: 193,
                  center_y: 87,
                  x: -35,
                  y: 0,
                  start_angle: 125,
                  end_angle: 398,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 159,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 143,
                  y: 38,
                  src: '183.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '238.png',
                  center_x: 193,
                  center_y: 85,
                  x: 12,
                  y: 33,
                  start_angle: -90,
                  end_angle: 90,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 170,
                  y: 102,
                  font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 148,
                  y: 40,
                  src: '176.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 152,
                  y: 96,
                  font_array: ["216.png","217.png","218.png","219.png","220.png","221.png","222.png","223.png","224.png","225.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: '226.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 149,
                  y: 40,
                  image_array: ["137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 170,
                  y: 70,
                  font_array: ["193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 149,
                  y: 40,
                  image_array: ["146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 10,
              src: '256.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_target_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 93,
              // circle_center_Y: 105,
              // font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
              // radius: 80,
              // angle: -36,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP_TARGET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_target_TextCircle_ASCIIARRAY[0] = '205.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[1] = '206.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[2] = '207.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[3] = '208.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[4] = '209.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[5] = '210.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[6] = '211.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[7] = '212.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[8] = '213.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[9] = '214.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 93,
                center_y: 105,
                pos_x: 93 - normal_step_target_TextCircle_img_width / 2,
                pos_y: 105 - 87,
                src: '205.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 423,
              font_array: ["257.png","258.png","259.png","260.png","261.png","262.png","263.png","264.png","265.png","266.png"],
              padding: false,
              h_space: -1,
              unit_sc: '268.png',
              unit_tc: '268.png',
              unit_en: '268.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: -10,
              src: '301.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: -10,
              image_array: ["301.png","302.png","303.png","304.png","305.png","306.png","307.png","308.png","309.png","310.png","311.png","312.png"],
              image_length: 12,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 43,
              y: 193,
              src: '54.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 197,
              font_array: ["92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 35,
              y: 254,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png"],
              image_length: 12,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 197,
              font_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 35,
              y: 287,
              image_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              image_length: 13,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 197,
              font_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 35,
              y: 218,
              image_array: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              image_length: 12,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 137,
              hour_array: ["270.png","271.png","272.png","273.png","274.png","275.png","276.png","277.png","278.png","279.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 152,
              minute_startY: 137,
              minute_array: ["270.png","271.png","272.png","273.png","274.png","275.png","276.png","277.png","278.png","279.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 266,
              second_startY: 137,
              second_array: ["280.png","281.png","282.png","283.png","284.png","285.png","286.png","287.png","288.png","289.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 124,
              y: 121,
              src: '290.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 121,
              src: '290.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 285,
              y: 59,
              week_en: ["249.png","250.png","251.png","252.png","253.png","254.png","255.png"],
              week_tc: ["249.png","250.png","251.png","252.png","253.png","254.png","255.png"],
              week_sc: ["249.png","250.png","251.png","252.png","253.png","254.png","255.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 275,
              day_startY: 80,
              day_sc_array: ["239.png","240.png","241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png"],
              day_tc_array: ["239.png","240.png","241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png"],
              day_en_array: ["239.png","240.png","241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png"],
              day_zero: 0,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '204.png',
              center_x: 90,
              center_y: 369,
              x: -35,
              y: 0,
              start_angle: 126,
              end_angle: 397,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 19,
              font_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
              padding: false,
              h_space: 0,
              dot_image: '227.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 46,
              y: 323,
              w: 90,
              h: 90,
              src: '179.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 197,
              w: 307,
              h: 100,
              src: '179.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 41,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 1,
              press_src: '179.png',
              normal_src: '179.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_target_STEP');
              let targetStep = step.target;
              let normal_step_target_circle_string = parseInt(targetStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -36;
                if (targetStep != null && targetStep != undefined && isFinite(targetStep) && normal_step_target_circle_string.length > 0 && normal_step_target_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_target_TextCircle_img_angle = 0;
                  let normal_step_target_TextCircle_dot_img_angle = 0;
                  normal_step_target_TextCircle_img_angle = toDegree(Math.atan2(normal_step_target_TextCircle_img_width/2, 80));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_target_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_target_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 93 - normal_step_target_TextCircle_img_width / 2);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_target_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_target_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update editable circle_scale BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_editableZone_2_battery = progressBattery;

                if (editableZone_2_battery_circle_scale) {

                  // editableZone_2_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_battery * 100);
                  if (editableZone_2_battery_circle_scale) {
                    editableZone_2_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 196,
                      center_y: 370,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 41,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF21DE6C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_3_battery = progressBattery;

                if (editableZone_3_battery_circle_scale) {

                  // editableZone_3_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_battery * 100);
                  if (editableZone_3_battery_circle_scale) {
                    editableZone_3_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 299,
                      center_y: 370,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 41,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF21DE6C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_4_battery = progressBattery;

                if (editableZone_4_battery_circle_scale) {

                  // editableZone_4_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_4_battery * 100);
                  if (editableZone_4_battery_circle_scale) {
                    editableZone_4_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 90,
                      center_y: 85,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 41,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF21DE6C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_5_battery = progressBattery;

                if (editableZone_5_battery_circle_scale) {

                  // editableZone_5_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_5_battery * 100);
                  if (editableZone_5_battery_circle_scale) {
                    editableZone_5_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 194,
                      center_y: 85,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 41,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF21DE6C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}