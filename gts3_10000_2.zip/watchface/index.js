﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 323,
              y: 104,
              src: '0074.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 104,
              src: '0073.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 30,
              y: 104,
              src: '0071.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 96,
              y: 104,
              src: '0072.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 343,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 6,
              unit_sc: '0020.png',
              unit_tc: '0020.png',
              unit_en: '0020.png',
              negative_image: '0019.png',
              invalid_image: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 270,
              image_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 273,
              day_startY: 230,
              day_sc_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              day_tc_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              day_en_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 259,
              y: 179,
              week_en: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              week_tc: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              week_sc: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0086.png',
              center_x: 301,
              center_y: 225,
              posX: 24,
              posY: 66,
              start_angle: -25,
              end_angle: 335,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 232,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 6,
              invalid_image: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 320,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 67,
              // line_width: 5,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0018.png',
              center_x: 0,
              center_y: 0,
              x: 0,
              y: 0,
              start_angle: 0,
              end_angle: 360,
              cover_path: '0098.png',
              cover_x: 124,
              cover_y: 250,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 88,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 67,
              // line_width: 5,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0018.png',
              center_x: 89,
              center_y: 223,
              x: 67,
              y: 67,
              start_angle: 0,
              end_angle: 360,
              cover_path: '0098.png',
              cover_x: 18,
              cover_y: 155,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 196,
              font_array: ["0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 168,
              am_y: 104,
              am_sc_path: '0062.png',
              am_en_path: '0062.png',
              pm_x: 168,
              pm_y: 104,
              pm_sc_path: '0063.png',
              pm_en_path: '0063.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 38,
              hour_array: ["0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_unit_sc: '0085.png',
              hour_unit_tc: '0085.png',
              hour_unit_en: '0085.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 211,
              minute_startY: 38,
              minute_array: ["0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 11,
              hour_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 11,
              minute_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 11,
              second_posY: 187,
              second_cover_path: '0006.png',
              second_cover_x: 171,
              second_cover_y: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 41,
              w: 100,
              h: 100,
              src: '0018.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 263,
              w: 107,
              h: 117,
              src: '0018.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 230,
              w: 137,
              h: 73,
              src: '0018.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 150,
              w: 153,
              h: 73,
              src: '0018.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 273,
              day_startY: 230,
              day_sc_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              day_tc_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              day_en_array: ["0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 259,
              y: 179,
              week_en: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              week_tc: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              week_sc: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 168,
              am_y: 104,
              am_sc_path: '0099.png',
              am_en_path: '0099.png',
              pm_x: 168,
              pm_y: 104,
              pm_sc_path: '0100.png',
              pm_en_path: '0100.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 38,
              hour_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_unit_sc: '0097.png',
              hour_unit_tc: '0097.png',
              hour_unit_en: '0097.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 211,
              minute_startY: 38,
              minute_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 11,
              hour_posY: 187,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 11,
              minute_posY: 187,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 11,
              second_posY: 187,
              second_cover_path: '0006.png',
              second_cover_x: 171,
              second_cover_y: 201,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 195;
                  let center_y_normal_battery = 320;
                  let radius_normal_battery = 67;
                  let line_width_cs_normal_battery = 5;
                  let color_cs_normal_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 270;
                  let center_x_normal_step = 88;
                  let center_y_normal_step = 225;
                  let radius_normal_step = 67;
                  let line_width_cs_normal_step = 5;
                  let color_cs_normal_step = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  