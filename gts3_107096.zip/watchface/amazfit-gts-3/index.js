try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
        const n = e.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.app.__globals__),
            p = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_soqgj",
                    anim_ext: "png",
                    anim_fps: 15,
                    anim_size: 83,
                    repeat_count: 1,
                    anim_repeat: !1,
                    // display_on_restart: !0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 50,
                    hour_startY: 161,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: -2,
                    hour_unit_sc: "15.png",
                    hour_unit_tc: "15.png",
                    hour_unit_en: "15.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 2,
                    minute_startX: 206,
                    minute_startY: 161,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: -2,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 169,
                    am_y: 88,
                    am_sc_path: "16.png",
                    am_en_path: "17.png",
                    pm_x: 169,
                    pm_y: 88,
                    pm_sc_path: "18.png",
                    pm_en_path: "19.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 157,
                    y: 122,
                    week_en: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png"],
                    week_tc: ["27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png"],
                    week_sc: ["34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 171,
                    y: 266,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "52.png",
                    unit_tc: "52.png",
                    unit_en: "52.png",
                    invalid_image: "51.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 141,
                    y: 268,
                    src: "53.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 96,
                    y: 301,
                    src: "54.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 143,
                    y: 311,
                    w: 138,
                    type: hmUI.data_type.STEP,
                    font_array: ["55.png", "56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    invalid_image: "55.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 103,
                    y: 313,
                    src: "65.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 100,
                    y: 308,
                    w: 180,
                    h: 37,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "66.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 50,
                    hour_startY: 161,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: -2,
                    hour_unit_sc: "15.png",
                    hour_unit_tc: "15.png",
                    hour_unit_en: "15.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 206,
                    minute_startY: 161,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: -2,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                      console.log('ui resume');
                    //   anim.setProperty(
                    //     hmUI.prop.ANIM_STATUS,
                    //     hmUI.anim_status.STOP
                    //   );
                      anim.setProperty(
                        hmUI.prop.ANIM_STATUS,
                        hmUI.anim_status.START
                      );
                    },
                    pause_call: function () {
                      console.log('ui pause');
                    },
                  });
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (e) {
    console.log(e)
}