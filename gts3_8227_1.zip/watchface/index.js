﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_year_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 267,
              font_array: ["cz01.png","cz02.png","cz03.png","cz04.png","cz05.png","cz06.png","cz07.png","cz08.png","cz09.png","cz10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'tchk-green2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 268,
              src: 'dist1-size.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 12,
              year_startY: 200,
              year_sc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              year_tc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              year_en_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              year_zero: 1,
              year_space: -2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 205,
              src: '114.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 24,
              src: 'block-green-3-1.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 77,
              y: 28,
              src: 'bt-3-red.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 114,
              y: 26,
              src: 'alarm-yellow-3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 298,
              y: 200,
              week_en: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png"],
              week_tc: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png"],
              week_sc: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 200,
              day_sc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              day_tc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              day_en_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 200,
              month_sc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_tc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_en_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 205,
              src: '114.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 20,
              src: '16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 25,
              font_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 31,
              image_array: ["zar01.png","zar02.png","zar03.png","zar04.png","zar05.png","zar06.png","zar07.png","zar08.png","zar09.png","zar10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 330,
              font_array: ["136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 330,
              src: 'kalor1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 288,
              image_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 393,
              font_array: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 394,
              src: 'steps10-size.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 264,
              image_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 8,
              hour_startY: 84,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 184,
              minute_startY: 84,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 333,
              second_startY: 143,
              second_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 146,
              y: 89,
              src: '12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 336,
              am_y: 94,
              am_sc_path: '123.png',
              am_en_path: '123.png',
              pm_x: 336,
              pm_y: 94,
              pm_sc_path: '124.png',
              pm_en_path: '124.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 267,
              font_array: ["cz01.png","cz02.png","cz03.png","cz04.png","cz05.png","cz06.png","cz07.png","cz08.png","cz09.png","cz10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'tchk-green2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 268,
              src: 'dist1-size.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 12,
              year_startY: 200,
              year_sc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              year_tc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              year_en_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              year_zero: 1,
              year_space: -2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 205,
              src: '114.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 393,
              font_array: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 394,
              src: 'steps10-size.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 264,
              image_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 330,
              font_array: ["136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 330,
              src: 'kalor1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 288,
              image_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 24,
              src: 'block-green-3-1.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 77,
              y: 28,
              src: 'bt-3-red.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 114,
              y: 26,
              src: 'alarm-yellow-3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 298,
              y: 200,
              week_en: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png"],
              week_tc: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png"],
              week_sc: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 200,
              day_sc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              day_tc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              day_en_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 200,
              month_sc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_tc_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_en_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 205,
              src: '114.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 25,
              font_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 20,
              src: '16.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 31,
              image_array: ["zar01.png","zar02.png","zar03.png","zar04.png","zar05.png","zar06.png","zar07.png","zar08.png","zar09.png","zar10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 8,
              hour_startY: 84,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 184,
              minute_startY: 84,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 333,
              second_startY: 143,
              second_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 146,
              y: 89,
              src: '12.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 336,
              am_y: 94,
              am_sc_path: '123.png',
              am_en_path: '123.png',
              pm_x: 336,
              pm_y: 94,
              pm_sc_path: '124.png',
              pm_en_path: '124.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  